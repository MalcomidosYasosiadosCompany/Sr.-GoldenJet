print('Hello, Python 3!')
