#!/bin/sh
gcc test_fpu.c -o ./test_fpu
./test_fpu
