//
//  AboutNavigationController.h
//  iSH
//
//  Created by Theodore Dubois on 10/6/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AboutNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
