#include "emu/cpu.h"
#include "emu/tlb.h"

int undefined_flags_mask(struct cpu_state *cpu, struct tlb *tlb);
