void transplant_vdso(int pid, const void *new_vdso, size_t new_vdso_size);
